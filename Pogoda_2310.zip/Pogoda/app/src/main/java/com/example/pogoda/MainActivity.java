package com.example.pogoda;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView next = findViewById(R.id.nextBtn);

        next.setOnClickListener(view -> {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
        });
        new ApiTask().execute();
    }

    static class ApiTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            Api.api();
            return null;
        }
    }


}