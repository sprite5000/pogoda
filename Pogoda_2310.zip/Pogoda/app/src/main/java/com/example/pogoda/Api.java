package com.example.pogoda;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Api {
    static String[][] tablica;
    static String[][] tab1;

        public static void api() {
            try {
                String nazwa = "Warsaw";
                URL url = new URL("https://api.openweathermap.org/data/2.5/forecast?q="+nazwa+",pl&appid=2c45d0a2fa8abd500306eb4110a3bee3");
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.connect();
                int responseCode = httpURLConnection.getResponseCode();
                if (responseCode != 200) {
                    throw new RuntimeException("HttpResponseCode: " + responseCode);
                }
                else {
                    StringBuilder informationString = new StringBuilder();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
                    String line=reader.readLine();
                    informationString.append(line);


                    JSONObject jsonObject = new JSONObject(informationString.toString());
                    JSONArray listArray = jsonObject.getJSONArray("list");

                    tablica = new String[10][listArray.length()];

                    //tyl aplikacja!
                    int sum = 0;
                    for(int i = 0 ; i< 4; i++){


                        sum+=8;
                        JSONObject firstListObject = listArray.getJSONObject(sum);
                            String dt = firstListObject.getString("dt_txt");

                            JSONObject mainObject = firstListObject.getJSONObject("main");

                            double temp_max = mainObject.getDouble("temp_max");
                            double temp_maxC =temp_max - 273.15;
                            int result1 = (int) temp_maxC;
                            String temp_maximum = String.valueOf(result1);

                            double temp_min = mainObject.getDouble("temp_min");
                            double temp_minC =temp_min - 273.15;
                            int result2 = (int) temp_minC;
                            String temp_miniimum = String.valueOf(result2);

                            String pressure = mainObject.getString("pressure");

                            String humidity = mainObject.getString("humidity");

                            JSONObject windObject = firstListObject.getJSONObject("wind");
                            String speed = windObject.getString("speed");

                            JSONArray weatherArray = firstListObject.getJSONArray("weather");
                            JSONObject weatherObject = weatherArray.getJSONObject(0);

                            String main = weatherObject.getString("main");
                            String id = weatherObject.getString("icon");
                            String description = weatherObject.getString("description");

                            tablica[0][i]=main;
                            tablica[1][i]=id;
                            tablica[2][i]=description;
                            tablica[3][i]=temp_miniimum;
                            tablica[4][i]=temp_maximum;
                            tablica[5][i]=dt;
                            tablica[6][i]=humidity;
                            tablica[7][i]=speed;
                            tablica[8][i]=pressure;
                    }



                    tab1 = new String[10][listArray.length()];
                    for(int i = 0 ; i< listArray.length(); i++){


                        JSONObject firstListObject = listArray.getJSONObject(i);
                        String dt = firstListObject.getString("dt_txt");

                        JSONObject mainObject = firstListObject.getJSONObject("main");

                        double temp_max = mainObject.getDouble("temp_max");
                        double temp_maxC =temp_max - 273.15;
                        int result1 = (int) temp_maxC;
                        String temp_maximum = String.valueOf(result1);

                        double temp_min = mainObject.getDouble("temp_min");
                        double temp_minC =temp_min - 273.15;
                        int result2 = (int) temp_minC;
                        String temp_miniimum = String.valueOf(result2);

                        String pressure = mainObject.getString("pressure");

                        String humidity = mainObject.getString("humidity");

                        JSONObject windObject = firstListObject.getJSONObject("wind");
                        String speed = windObject.getString("speed");



                        JSONArray weatherArray = firstListObject.getJSONArray("weather");
                        JSONObject weatherObject = weatherArray.getJSONObject(0);

                        String main = weatherObject.getString("main");
                        String id = weatherObject.getString("icon");
                        String description = weatherObject.getString("description");


                        tab1[0][i]=main;
                        tab1[1][i]=id;
                        tab1[2][i]=description;
                        tab1[3][i]=temp_miniimum;
                        tab1[4][i]=temp_maximum;
                        tab1[5][i]=dt;
                        tab1[6][i]=humidity;
                        tab1[7][i]=speed;
                        tab1[8][i]=pressure;
                    }
                }
            } catch (Exception e) {
                System.out.println("Błąd"+" "+e.getMessage());
            }
        }
}
