package com.example.pogoda;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

public class MainActivity2 extends AppCompatActivity {
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pogoda2);

        WeatherTableBack[] weathers = new WeatherTableBack[15];

        LocalDate currentDate = LocalDate.now();
        String[] days = new String[3];
        for(int i = 0; i<3;i++){
            LocalDate twoDaysAhead = currentDate.plusDays(2+i);
            DayOfWeek dayOfWeek = twoDaysAhead.getDayOfWeek();
            String day = dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault());
            days[i]=day;
        }

        WeatherTommorow weatherTommorow = new WeatherTommorow(this,Api.tablica[5][0],Api.tablica[0][0],Api.tablica[4][0]);
        weatherTommorow.wyswietl(Api.tablica[8][0],Api.tablica[7][0],Api.tablica[6][0]);

        for(int i = 1,j=0 ; i < 4 ; i++,j++){
            weathers[i] = new WeatherTableBack(this,this,days[j],Api.tablica[0][i],Api.tablica[4][i],Api.tab1[3][i+3]);
            weathers[i].wyswietl();
        }

        back = findViewById(R.id.back);
        back.setOnClickListener(view ->  {
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
        });
    }
}